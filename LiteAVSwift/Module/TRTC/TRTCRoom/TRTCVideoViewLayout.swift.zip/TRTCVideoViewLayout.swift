//
//  TRTCVideoViewLayout.swift
//  TRTCSwift
//
//  Created by issuser on 2020/7/22.
//  Copyright © 2020 issuser. All rights reserved.
//

import UIKit

let VSPACE:CGFloat = 10.0
let HSPACE:CGFloat = 20.0
let MARGIN:CGFloat = 10.0


class TRTCVideoViewLayout: NSObject {
   
    var view:UIView!
    let positionData = [8,5,2,6,3,7,0,3,4,1]
    var type:TCLayoutType! = .TC_Float{
        didSet{
            self.relayout(players: self.subViews)
        }
    }
    
    var subViews:Array<TRTCVideoView>!
    
    func relayout(players:Array<TRTCVideoView>){
        
    
        
    }

    func relayout1(players:Array<TRTCVideoView>){
        self.subViews = players
        
        for player in self.subViews {
            self.view.addSubview(player)
            self.view.bringSubviewToFront(player)
            
            player.isUserInteractionEnabled = true
            
            let needBtnHidde = ((type == .TC_Float) || (type == .TC_Gird && player.type == .local))
            needBtnHidde ? player.hideButtons(isHidden: true):nil
        }
        
        if(players.count == 1){
            players.first?.frame = .init(origin: .zero, size: self.view.frame.size)
            return
        }
        
        if(players.count == 0){
            return
        }
        
        UIView.beginAnimations("TRTCLayoutEngine", context: nil)
        UIView.setAnimationDuration(0.25)
        
        switch self.type {
        case .TC_Float:
            players[0].frame = .init(origin: .zero, size: self.view.frame.size)
            for i in 1 ..< players.count{
                players[i].frame = self.grid(total: 9, at: positionData[i])
            }
            
            break
        case .TC_Gird:
            for player in players{
                player.frame = self.grid(total: players.count, at: players.firstIndex(of: player)!)
            }
            break
        default:
            break
        }
        
        UIView.commitAnimations()
        
        DispatchQueue.main.asyncAfter(deadline: .now() + 5) {
            debugPrint("当前用户数量:\(self.subViews.count)")
            
            for player in self.subViews{
                
                debugPrint("用户Id:\(player.userId)是否本地\(player.type) 父视图 \(player.superview?.classForCoder) frame \(player.frame)")
                
            }
            
        }
    }
    
    // 将view等分为total块，处理好边距
    func grid(total:Int,at:Int) ->CGRect{

        var atRect:CGRect = .zero
        let H:CGFloat = self.view.frame.size.height
        let W:CGFloat = self.view.frame.size.width

        // 等分主view，2、4、9...
        // 6宫格不能处理
        if total <= 2 {
            atRect.size.width = (W - HSPACE - 2 * MARGIN) / 2
            atRect.size.height = FitH(rect: atRect)
            atRect.origin.y = (H-atRect.size.height)/2
            if (at == 0) {
                atRect.origin.x = MARGIN
            } else {
                atRect.origin.x = W-MARGIN-atRect.size.width
            }
            return atRect

        }else if (total < 4){
           atRect.size.width = (W - HSPACE - 2 * MARGIN) / 2
            atRect.size.height = FitH(rect: atRect)
            if (at / 2 == 0) {
                atRect.origin.y = (H - VSPACE)/2-atRect.size.height
            } else {
                atRect.origin.y = (H + VSPACE)/2
            }

            if (at % 2 == 0) {
                atRect.origin.x = MARGIN
            } else {
                atRect.origin.x = W-MARGIN-atRect.size.width
            }
            return atRect

        } else if (total <= 6) {
               atRect.size.width = (W - 2 * HSPACE - 2 * MARGIN) / 3
               atRect.size.height = FitH(rect: atRect)
               if (at / 3 == 0) {
                   atRect.origin.y = H/2 - atRect.size.height - VSPACE
               } else {
                   atRect.origin.y = H/2 + VSPACE
               }

               if (at % 3 == 0) {
                   atRect.origin.x = MARGIN
               } else if (at % 3 == 1) {
                   atRect.origin.x = W/2 - atRect.size.width/2
               } else {
                   atRect.origin.x = W - atRect.size.width - MARGIN
               }
               return atRect
        }else {
            if (at >= 9) {
                return .zero
            }

            atRect.size.width = (W - 2 * HSPACE - 2 * MARGIN) / 3
            atRect.size.height = FitH(rect: atRect)
            if (at / 3 == 0) {
                atRect.origin.y = H/2 - atRect.size.height/2 - VSPACE - atRect.size.height
            } else if (at / 3 == 1) {
                atRect.origin.y = H/2 - atRect.size.height/2
            } else {
                atRect.origin.y = H/2 + atRect.size.height/2 + VSPACE
            }

            if (at % 3 == 0) {
                atRect.origin.x = MARGIN
            } else if (at % 3 == 1) {
                atRect.origin.x = W/2 - atRect.size.width/2
            } else {
                atRect.origin.x = W - atRect.size.width - MARGIN
            }
            return atRect
        }
    }

    func FitH(rect:CGRect) -> CGFloat{
        return (rect.size.width / 9.0) * 16
    }
    
}
